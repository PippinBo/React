# ReactJS-BMRCalculator
Basal Metabolic Rate is the number of calories required to keep your body functioning at rest.To get your BMR, simply input your height, gender, age and weight below. Once you’ve determined your BMR, you can begin to monitor how many calories a day you need to maintain or lose weight.
