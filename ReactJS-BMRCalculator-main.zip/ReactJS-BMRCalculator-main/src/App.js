import Bmr from './components/Bmr';
import './components/bmr.css';

function App() {
  return (
    <div className="App">
      <Bmr/>
      
    </div>
  );
}

export default App;
