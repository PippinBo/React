import React from "react";
import './App.css';
import BMR from './bmr';

function App() {
  return (
   <BMR />
  );
}

export default App;